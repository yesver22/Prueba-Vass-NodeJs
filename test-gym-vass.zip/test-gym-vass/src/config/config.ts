export default{
    jwtSecret: 'DBPEK#'
}