import {getRepository} from "typeorm";
import {NextFunction, Request, Response} from "express";
import {User} from "../entity/User";
import {Validate} from 'class-validator' 

export class UserController {

    static getAll = async(request: Request, response: Response, next: NextFunction)=> {
        const userRepository = getRepository(User);
        const users = await userRepository.find();

        if(users.length > 0){
            response.send(users);
        }else{
            response.status(400).json({mensage:"sin resultados"});
        }
    };

    static getById = async(request: Request, response: Response, next: NextFunction)=> {

        const {id} = request.params;
        const userRepository = getRepository(User);

        try {
            const user = await userRepository.findOneOrFail(id);
            response.send(user);
        } catch (error) {
            response.status(400).json({mensage:"sin resultados"});
        }
    };

}