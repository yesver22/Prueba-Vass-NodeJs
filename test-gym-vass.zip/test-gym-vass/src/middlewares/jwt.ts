import {Request,Response,NextFunction} from 'express'
import * as jwt from 'jsonwebtoken'
import config from '../config/config'

export const checkJwt = (req:Request,res:Response,next:NextFunction)=>{

    const token = <string>req.headers['auth'];
    let jwtPayload;

    try {
        
        jwtPayload = <any>jwt.verify(token,config.jwtSecret);
        res.locals.jwtPayload = jwtPayload;

    } catch (error) {
        return res.status(401).json({message:' No existe token '});
    }
    
    const {id,usNombre} = jwtPayload;

    const newToken = jwt.sign({id,usNombre},config.jwtSecret,{expiresIn :'60'});
    res.setHeader('token',newToken);
    next();

};