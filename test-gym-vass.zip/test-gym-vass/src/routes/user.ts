import {Router} from 'express'
import {UserController} from '../controller/UserController'
import { checkJwt } from '../middlewares/jwt'

const router = Router();

router.get("/",[checkJwt], UserController.getAll);

router.get("/:id",[checkJwt], UserController.getById);

export default router;
